
rootProject.name = "AnimeBank"

