class Conta {

    var titular = ""
    var numero = 0
    var saldo = 0.0

    constructor(titular: String, numero: Int) {
        this.titular = titular
        this.numero = numero
    }

    constructor()

    fun depositar(valor: Double) {
        saldo += valor;
    }

    fun sacar(valor: Double) {
        saldo -= valor;
    }

    fun transfere(valor: Double, contaDestino: Conta): Boolean {
        if (saldo >= valor) {
            saldo -= valor

            contaDestino.depositar(valor)

            return true
        }

        return false
    }
}