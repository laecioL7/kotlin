fun main(args: Array<String>) {
    println("Bem-vindo ao anime bank!")

    testaComportamentosConta()
}


